msg = "Hello World"
a = 2
b = 3
sum1 = a + b
print(a, "+", b, "=",sum1)
c = int(input("choose a number between 1-100 then  hit enter: "))
d = int(input("choose another number between 1-100 then  hit enter: "))
var = "The sum of the numbers you choose is:"
sum2 = c + d
print(var,sum2)

